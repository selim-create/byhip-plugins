<?php
/**
 * Plugin Name: HIP Monitor Agent
 * Description: Read-only WordPress health information for an explicitly paired HIP Control.
 * Version: 0.2.0
 * Plugin URI: https://plugin.byhip.studio/hip-monitor-agent/
 * Author: byhip.studio
 * Update URI: https://plugin.byhip.studio/hip-monitor-agent/
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */

if (!defined('ABSPATH')) { exit; }

define('HIP_MONITOR_AGENT_VERSION', '0.2.0');
define('HIP_MONITOR_AGENT_FILE', __FILE__);
require_once __DIR__ . '/includes/updater.php';

define('HIP_MONITOR_PATH', '/wp-json/hip-monitor/v1/health');

add_action('rest_api_init', function () {
    register_rest_route('hip-monitor/v1', '/health', array(
        'methods' => 'GET',
        'callback' => 'hip_monitor_health',
        'permission_callback' => 'hip_monitor_authorized',
    ));
});

function hip_monitor_authorized($request) {
    $key = defined('HIP_MONITOR_AGENT_KEY') ? HIP_MONITOR_AGENT_KEY : '';
    if (!is_string($key) || !preg_match('/^[a-f0-9]{64}$/D', $key)) {
        return new WP_Error('hip_monitor_unconfigured', 'Monitor is not configured.', array('status' => 403));
    }
    // Header names are case-insensitive in WP_REST_Request.
    $time = (string) $request->get_header('x-hip-monitor-time');
    $nonce = (string) $request->get_header('x-hip-monitor-nonce');
    $sig = (string) $request->get_header('x-hip-monitor-signature');
    if (!preg_match('/^[0-9]{10,11}$/D', $time) || !preg_match('/^[a-f0-9]{32}$/D', $nonce) || !preg_match('/^[a-f0-9]{64}$/D', $sig)) {
        return new WP_Error('hip_monitor_unauthorized', 'Unauthorized.', array('status' => 403));
    }
    if (abs(time() - (int) $time) > 120) {
        return new WP_Error('hip_monitor_expired', 'Expired request.', array('status' => 403));
    }
    // Canonical path is independent of a WordPress installation subdirectory.
    $signed = "GET\n" . HIP_MONITOR_PATH . "\n" . $time . "\n" . $nonce;
    $expected = hash_hmac('sha256', $signed, hex2bin($key));
    if (!hash_equals($expected, $sig)) {
        return new WP_Error('hip_monitor_unauthorized', 'Unauthorized.', array('status' => 403));
    }
    // Atomic add_option makes each nonce single-use across PHP workers.
    // Old nonces are deleted by WP-Cron; new requests cannot reuse them while stored.
    $nonce_name = '_hip_monitor_nonce_' . $nonce;
    if (!add_option($nonce_name, time(), '', 'no')) {
        return new WP_Error('hip_monitor_replay', 'Repeated request.', array('status' => 403));
    }
    if (wp_rand(1, 50) === 1) {
        $wpdb = $GLOBALS['wpdb'];
        $cutoff = time() - 600;
        // Only delete plugin-owned, time-expired nonce options.
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) < %d",
            $wpdb->esc_like('_hip_monitor_nonce_') . '%', $cutoff
        ));
    }
    return true;
}

function hip_monitor_health() {
    if (!function_exists('get_plugin_updates')) {
        require_once ABSPATH . 'wp-admin/includes/update.php';
    }
    if (!function_exists('get_plugins')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    $plugins = get_option('active_plugins', array());
    $core = get_site_transient('update_core');
    $plugin_updates = get_site_transient('update_plugins');
    $theme_updates = get_site_transient('update_themes');
    $core_available = false;
    if (is_object($core) && !empty($core->updates) && is_array($core->updates)) {
        foreach ($core->updates as $item) {
            if (isset($item->response) && $item->response === 'upgrade') { $core_available = true; break; }
        }
    }
    return rest_ensure_response(array(
        'wordpressVersion' => get_bloginfo('version'),
        'phpVersion' => PHP_VERSION,
        'activePlugins' => is_array($plugins) ? count($plugins) : 0,
        'pluginUpdates' => is_object($plugin_updates) && isset($plugin_updates->response) && is_array($plugin_updates->response) ? count($plugin_updates->response) : 0,
        'themeUpdates' => is_object($theme_updates) && isset($theme_updates->response) && is_array($theme_updates->response) ? count($theme_updates->response) : 0,
        'coreUpdateAvailable' => $core_available,
        'multisite' => is_multisite(),
    ));
}

add_filter('rest_post_dispatch', function ($result, $server, $request) {
    if ($request->get_route() === '/hip-monitor/v1/health') {
        nocache_headers();
    }
    return $result;
}, 10, 3);
