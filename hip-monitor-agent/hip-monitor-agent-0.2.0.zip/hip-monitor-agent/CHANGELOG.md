# HIP Monitor Agent

## 0.2.0
- Bağımsız sürüm kontrolü ve otomatik güncelleme; yalnızca plugin.byhip.studio/hip-monitor-agent adresinden paket kabul edilir.
- Paket SHA-256 bütünlüğü doğrulanmadan yüklenmez.
- Mevcut HIP Control eşleştirme anahtarı ve salt okunur sağlık endpoint'i korunur.

## 0.1.0
- İmzalı ve salt okunur WordPress sağlık bilgileri.
