<?php
/**
 * HIP Monitor Agent's independent, checksum-verified WordPress update feed.
 *
 * The agent has no dependency on Hip Press Bridge, Hip Shield, or HIP Admin.
 * This updater only claims packages under /hip-monitor-agent/, leaving other
 * byhip plugins' downloads untouched.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('HIP_MONITOR_UPDATE_URL', 'https://plugin.byhip.studio/hip-monitor-agent/info.json');
define('HIP_MONITOR_RELEASE_CACHE', 'hip_monitor_agent_release');

function hip_monitor_plugin_basename() {
    return plugin_basename(HIP_MONITOR_AGENT_FILE);
}

/** Never intercept the independent Hip Space Bridge or HIP Shield packages. */
function hip_monitor_trusted_package($url) {
    if (!is_string($url)) {
        return false;
    }
    $parts = wp_parse_url($url);
    return is_array($parts)
        && isset($parts['scheme'], $parts['host'], $parts['path'])
        && $parts['scheme'] === 'https'
        && strtolower($parts['host']) === 'plugin.byhip.studio'
        && !isset($parts['user']) && !isset($parts['pass'])
        && !isset($parts['port']) && !isset($parts['query']) && !isset($parts['fragment'])
        && preg_match('~^/hip-monitor-agent/hip-monitor-agent-[0-9]+\.[0-9]+\.[0-9]+\.zip$~D', $parts['path']) === 1;
}

function hip_monitor_release($fresh = false) {
    if (!$fresh) {
        $cached = get_site_transient(HIP_MONITOR_RELEASE_CACHE);
        if (is_array($cached)) {
            return isset($cached['version']) ? $cached : null;
        }
    }
    $release = null;
    $response = wp_safe_remote_get(HIP_MONITOR_UPDATE_URL, array(
        'timeout' => 8,
        'redirection' => 0,
        'limit_response_size' => 8192,
        'headers' => array('Accept' => 'application/json'),
    ));
    if (!is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) === 200) {
        $data = json_decode((string) wp_remote_retrieve_body($response), true);
        if (is_array($data)
            && isset($data['version'], $data['download_url'], $data['sha256'])
            && is_string($data['version']) && preg_match('/^[0-9]+\.[0-9]+\.[0-9]+$/D', $data['version'])
            && hip_monitor_trusted_package($data['download_url'])
            && $data['download_url'] === 'https://plugin.byhip.studio/hip-monitor-agent/hip-monitor-agent-' . $data['version'] . '.zip'
            && is_string($data['sha256']) && preg_match('/^[a-f0-9]{64}$/D', $data['sha256'])) {
            $release = $data;
        }
    }
    set_site_transient(HIP_MONITOR_RELEASE_CACHE, $release ?: array('failed' => true), $release ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS);
    return $release;
}

function hip_monitor_release_text($release, $name, $default = '') {
    return is_array($release) && isset($release[$name]) && is_string($release[$name])
        ? $release[$name]
        : $default;
}

function hip_monitor_release_update_item($release) {
    return array(
        'id' => 'https://plugin.byhip.studio/hip-monitor-agent/',
        'slug' => 'hip-monitor-agent',
        'plugin' => hip_monitor_plugin_basename(),
        'version' => $release['version'],
        'new_version' => $release['version'],
        'url' => 'https://plugin.byhip.studio/hip-monitor-agent/',
        'package' => $release['download_url'],
        'requires' => hip_monitor_release_text($release, 'requires', '6.2'),
        'requires_php' => hip_monitor_release_text($release, 'requires_php', '7.4'),
        'tested' => hip_monitor_release_text($release, 'tested'),
        'autoupdate' => true,
        'icons' => array(),
        'banners' => array(),
        'banners_rtl' => array(),
        'translations' => array(),
    );
}

add_filter('update_plugins_plugin.byhip.studio', static function ($update, $plugin_data, $plugin_file) {
    if ($plugin_file !== hip_monitor_plugin_basename()) {
        return $update;
    }
    $release = hip_monitor_release();
    return $release ? hip_monitor_release_update_item($release) : $update;
}, 10, 3);

add_filter('site_transient_update_plugins', static function ($transient) {
    if (!is_admin() && !wp_doing_cron()) {
        return $transient;
    }
    $release = hip_monitor_release();
    if (!$release) {
        return $transient;
    }
    if (!is_object($transient)) {
        $transient = new stdClass();
    }
    if (!isset($transient->response) || !is_array($transient->response)) {
        $transient->response = array();
    }
    if (!isset($transient->no_update) || !is_array($transient->no_update)) {
        $transient->no_update = array();
    }
    $basename = hip_monitor_plugin_basename();
    $item = (object) hip_monitor_release_update_item($release);
    if (version_compare($release['version'], HIP_MONITOR_AGENT_VERSION, '>')) {
        $transient->response[$basename] = $item;
        unset($transient->no_update[$basename]);
    } else {
        $item->package = '';
        $transient->no_update[$basename] = $item;
        unset($transient->response[$basename]);
    }
    return $transient;
});

add_filter('plugins_api', static function ($result, $action, $args) {
    if ($action !== 'plugin_information' || !is_object($args) || !isset($args->slug) || $args->slug !== 'hip-monitor-agent') {
        return $result;
    }
    $release = hip_monitor_release();
    if (!$release) {
        return $result;
    }
    return (object) array(
        'name' => 'HIP Monitor Agent',
        'slug' => 'hip-monitor-agent',
        'version' => $release['version'],
        'author' => '<a href="https://byhip.studio">byhip.studio</a>',
        'homepage' => 'https://plugin.byhip.studio/hip-monitor-agent/',
        'requires' => hip_monitor_release_text($release, 'requires', '6.2'),
        'requires_php' => hip_monitor_release_text($release, 'requires_php', '7.4'),
        'tested' => hip_monitor_release_text($release, 'tested'),
        'last_updated' => hip_monitor_release_text($release, 'released_at'),
        'download_link' => $release['download_url'],
        'sections' => array(
            'description' => 'HIP Control için site sahibinin onayıyla çalışan salt okunur WordPress sağlık bağlantısı.',
            'changelog' => wp_kses_post(hip_monitor_release_text($release, 'changelog_html')),
        ),
    );
}, 10, 3);

add_filter('auto_update_plugin', static function ($enabled, $item) {
    if (is_object($item) && isset($item->plugin) && $item->plugin === hip_monitor_plugin_basename()) {
        return true;
    }
    return $enabled;
}, 10, 2);

/** Check the exact agent package checksum before WordPress installs it. */
add_filter('upgrader_pre_download', static function ($reply, $package) {
    if ($reply !== false || !hip_monitor_trusted_package($package)) {
        return $reply;
    }
    $release = hip_monitor_release(true);
    if (!$release || $release['download_url'] !== $package) {
        return new WP_Error('hip_monitor_release_mismatch', 'Monitor paketinin sürüm bilgisi geçersiz.');
    }
    if (!function_exists('download_url')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    $file = download_url($package, 300);
    if (is_wp_error($file)) {
        return $file;
    }
    if (!hash_equals($release['sha256'], (string) hash_file('sha256', $file))) {
        wp_delete_file($file);
        return new WP_Error('hip_monitor_checksum', 'HIP Monitor Agent ZIP SHA-256 doğrulaması başarısız.');
    }
    return $file;
}, 8, 2);
