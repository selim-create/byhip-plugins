# HIP Monitor Agent (0.2.0)

Small, standalone, **read-only** WordPress plugin. No HIP Admin, HIP Shield or editorial HIP Press Bridge dependency.

Install this plugin on an authorized customer WordPress site and configure `HIP_MONITOR_AGENT_KEY` in that site's **wp-config.php**. The key is supplied only to the site owner, never by URL, query string, or Git.

```php
define('HIP_MONITOR_AGENT_KEY', '<a separate 64-character hex key provisioned for this specific site>');
```

Endpoint: `GET /wp-json/hip-monitor/v1/health`. Request headers:
`X-Hip-Monitor-Time` (Unix seconds), `X-Hip-Monitor-Nonce` (random 16 bytes hex), `X-Hip-Monitor-Signature` (HMAC-SHA256 hex). Signature input is exactly `GET\n/wp-json/hip-monitor/v1/health\n<TIME>\n<NONCE>`; key bytes are hex-decoded.

Nonce is single use; signed requests expire after 120 seconds. Stored nonces are opportunistically cleaned up. Responses contain only version and aggregate update counts: no usernames, passwords, plugin names, URLs, content or server paths.

**Current status**: HIP Control supports explicitly approved pairing, revocation and on-demand read-only health checks. Version 0.2.0 adds a separate, checksum-verified WordPress auto-updater. New, consent-based discovery / one-click pairing is a separate planned feature and **not** included here.

Release source lives in the private Hip Space repo. Build with `npm run space -- plugin:build --plugin=hip-monitor-agent --out=../byhip-plugins`; review the ZIP and manifest before publication to `plugin.byhip.studio`. Do not publish secrets or a `.env` file.
