# Hip Space Bridge

## 0.3.0
- Bio sayfası verisi: hip.space'in Instagram'da paylaştığı içerikler (kapak ve yazı adresi) ve mecranın sosyal hesapları. Herkese açık `hip-press/v1/bio`; hip.space `PUT hip-press/v1/bio` ve `POST hip-press/v1/bio/covers` ile gönderir.
- Kapaklar ortam kütüphanesine girmez: `uploads/hip-press-bio/` altında, 720 px genişliğinde JPEG olarak durur.

## 0.2.0
- Kendini güncelliyor: yeni sürümler plugin.byhip.studio'dan gelir; Eklentiler sayfasında WordPress'in "Şimdi güncelle" düğmesi çıkar ve otomatik güncelleme açıktır.
- Paket yalnız plugin.byhip.studio'dan ve SHA-256 özeti tutarsa kurulur.
- hip.space için sürüm bilgisi (`hip-press/v1/bridge`) ve "şimdi güncelle" (`hip-press/v1/bridge/update`) uç noktaları.

## 0.1.0
- Taslakların SEO bilgileri (Rank Math başlık, açıklama, odak anahtar kelime) ve kısa adres.
