<?php
/**
 * Plugin Name: Hip Space Bridge
 * Plugin URI: https://plugin.byhip.studio/hip-press-bridge/
 * Description: Draft-only REST bridge for Hip Space SEO metadata delivery and the bio page data. Updates itself from plugin.byhip.studio. The folder name (hip-press-bridge) and REST namespace (hip-press/v1) stay for existing sites.
 * Version: 0.3.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: byhip.studio
 * Author URI: https://byhip.studio
 * Update URI: https://plugin.byhip.studio/hip-press-bridge/
 */

if (!defined('ABSPATH')) {
    exit;
}

define('HIP_PRESS_BRIDGE_VERSION', '0.3.0');
define('HIP_PRESS_BRIDGE_FILE', __FILE__);

require_once __DIR__ . '/includes/updater.php';
require_once __DIR__ . '/includes/bio.php';

add_action('rest_api_init', static function () {
    register_rest_route('hip-press/v1', '/drafts/(?P<id>\d+)/seo', [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => 'hip_press_bridge_get_draft_seo',
            'permission_callback' => 'hip_press_bridge_can_edit_draft',
        ],
        [
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => 'hip_press_bridge_update_draft_seo',
            'permission_callback' => 'hip_press_bridge_can_edit_draft',
            'args' => [
                'slug' => ['required' => true, 'type' => 'string'],
                'seoTitle' => ['required' => true, 'type' => 'string'],
                'seoDescription' => ['required' => true, 'type' => 'string'],
                'focusKeyword' => ['required' => true, 'type' => 'string'],
            ],
        ],
    ]);
});

function hip_press_bridge_can_edit_draft(WP_REST_Request $request) {
    $post_id = (int) $request['id'];
    return $post_id > 0 && current_user_can('edit_post', $post_id);
}

function hip_press_bridge_require_draft($post_id) {
    $post = get_post($post_id);
    if (!$post || $post->post_type !== 'post') {
        return new WP_Error('hip_press_post_not_found', 'Target post was not found.', ['status' => 404]);
    }
    if ($post->post_status !== 'draft') {
        return new WP_Error('hip_press_not_draft', 'Target post is not a draft.', ['status' => 409]);
    }
    return $post;
}

function hip_press_bridge_payload($post_id) {
    $post = get_post($post_id);
    return [
        'postId' => (int) $post_id,
        'status' => $post ? $post->post_status : null,
        'slug' => $post ? $post->post_name : null,
        'rankMath' => [
            'title' => (string) get_post_meta($post_id, 'rank_math_title', true),
            'description' => (string) get_post_meta($post_id, 'rank_math_description', true),
            'focusKeyword' => (string) get_post_meta($post_id, 'rank_math_focus_keyword', true),
        ],
    ];
}

function hip_press_bridge_get_draft_seo(WP_REST_Request $request) {
    $post_id = (int) $request['id'];
    $post = hip_press_bridge_require_draft($post_id);
    if (is_wp_error($post)) {
        return $post;
    }
    return rest_ensure_response(hip_press_bridge_payload($post_id));
}

function hip_press_bridge_update_draft_seo(WP_REST_Request $request) {
    $post_id = (int) $request['id'];
    $post = hip_press_bridge_require_draft($post_id);
    if (is_wp_error($post)) {
        return $post;
    }

    $slug = sanitize_title((string) $request->get_param('slug'));
    $seo_title = sanitize_text_field((string) $request->get_param('seoTitle'));
    $seo_description = sanitize_text_field((string) $request->get_param('seoDescription'));
    $focus_keyword = sanitize_text_field((string) $request->get_param('focusKeyword'));

    if ($slug === '' || $seo_title === '' || $seo_description === '' || $focus_keyword === '') {
        return new WP_Error('hip_press_invalid_seo', 'SEO payload contains an empty required field.', ['status' => 400]);
    }

    $updated = wp_update_post([
        'ID' => $post_id,
        'post_name' => $slug,
    ], true);
    if (is_wp_error($updated)) {
        return $updated;
    }

    update_post_meta($post_id, 'rank_math_title', $seo_title);
    update_post_meta($post_id, 'rank_math_description', $seo_description);
    update_post_meta($post_id, 'rank_math_focus_keyword', $focus_keyword);

    return rest_ensure_response(hip_press_bridge_payload($post_id));
}
