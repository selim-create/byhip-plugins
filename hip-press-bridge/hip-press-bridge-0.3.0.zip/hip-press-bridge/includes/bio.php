<?php
/**
 * The publication's bio page data ("link in bio"): what hip.space shared on Instagram, each with
 * its cover and the article's address, plus the publication's social accounts.
 *
 * - hip.space sends covers to POST hip-press/v1/bio/covers (the PNG itself). They are kept in
 *   uploads/hip-press-bio/<sha256>.jpg, made smaller for the web, outside the media library.
 * - hip.space then sends the list to PUT hip-press/v1/bio. Covers are named by their SHA-256 and
 *   must already be on the site; article addresses must be on the site's own domain.
 * - Anyone can read GET hip-press/v1/bio: the site's bio page (a theme, or a headless frontend
 *   such as hipinup.com/bio) draws it.
 */

if (!defined('ABSPATH')) {
    exit;
}

const HIP_PRESS_BIO_OPTION = 'hip_press_bio';
const HIP_PRESS_BIO_DIR = 'hip-press-bio';
const HIP_PRESS_BIO_MAX_ITEMS = 30;
const HIP_PRESS_BIO_COVER_WIDTH = 720;
const HIP_PRESS_BIO_SOCIAL_PLATFORMS = ['instagram', 'x', 'facebook', 'linkedin', 'youtube', 'tiktok', 'threads', 'pinterest', 'bluesky', 'whatsapp', 'telegram', 'spotify', 'other'];

function hip_press_bio_can_write() {
    return current_user_can('edit_others_posts');
}

/** uploads/hip-press-bio as a path and an address. */
function hip_press_bio_dir() {
    $uploads = wp_upload_dir(null, false);
    return [
        'path' => trailingslashit($uploads['basedir']) . HIP_PRESS_BIO_DIR,
        'url' => trailingslashit($uploads['baseurl']) . HIP_PRESS_BIO_DIR,
    ];
}

/** The stored cover for a SHA-256, or null. */
function hip_press_bio_cover($sha) {
    if (!is_string($sha) || !preg_match('/^[a-f0-9]{64}$/', $sha)) {
        return null;
    }
    $dir = hip_press_bio_dir();
    foreach (['jpg', 'png'] as $extension) {
        $file = $dir['path'] . '/' . $sha . '.' . $extension;
        if (is_file($file)) {
            $size = @getimagesize($file);
            return [
                'sha256' => $sha,
                'file' => $sha . '.' . $extension,
                'url' => $dir['url'] . '/' . $sha . '.' . $extension,
                'width' => $size ? (int) $size[0] : null,
                'height' => $size ? (int) $size[1] : null,
            ];
        }
    }
    return null;
}

/** The host the site is read on and the hosts that belong to it (api.example.com and example.com). */
function hip_press_bio_host_allowed($host) {
    $host = strtolower((string) $host);
    if ($host === '') {
        return false;
    }
    foreach ([home_url(), site_url()] as $own) {
        $own_host = strtolower((string) wp_parse_url($own, PHP_URL_HOST));
        if ($own_host === '') {
            continue;
        }
        $bare = preg_replace('/^(www|api|cms|admin|wp)\./', '', $own_host);
        if ($host === $own_host || $host === $bare || substr($host, -strlen('.' . $bare)) === '.' . $bare) {
            return true;
        }
    }
    return false;
}

add_action('rest_api_init', static function () {
    register_rest_route('hip-press/v1', '/bio', [
        [
            'methods' => WP_REST_Server::READABLE,
            'callback' => 'hip_press_bio_read',
            'permission_callback' => '__return_true',
        ],
        [
            'methods' => WP_REST_Server::EDITABLE,
            'callback' => 'hip_press_bio_save',
            'permission_callback' => 'hip_press_bio_can_write',
        ],
    ]);
    register_rest_route('hip-press/v1', '/bio/covers', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'hip_press_bio_upload_cover',
        'permission_callback' => 'hip_press_bio_can_write',
    ]);
    register_rest_route('hip-press/v1', '/bio/covers/(?P<sha>[a-f0-9]{64})', [
        'methods' => WP_REST_Server::READABLE,
        'callback' => static function (WP_REST_Request $request) {
            $cover = hip_press_bio_cover((string) $request['sha']);
            return $cover ? rest_ensure_response($cover) : new WP_Error('hip_press_bio_no_cover', 'Kapak bu sitede yok.', ['status' => 404]);
        },
        'permission_callback' => 'hip_press_bio_can_write',
    ]);
});

function hip_press_bio_read() {
    $stored = get_option(HIP_PRESS_BIO_OPTION);
    $stored = is_array($stored) ? $stored : [];
    $items = [];
    foreach (isset($stored['items']) && is_array($stored['items']) ? $stored['items'] : [] as $item) {
        $cover = isset($item['cover']) ? hip_press_bio_cover($item['cover']) : null;
        $items[] = [
            'id' => $item['id'],
            'title' => $item['title'],
            'url' => $item['url'],
            'image' => $cover ? $cover['url'] : null,
            'width' => $cover ? $cover['width'] : null,
            'height' => $cover ? $cover['height'] : null,
            'sharedAt' => $item['sharedAt'],
        ];
    }
    $response = rest_ensure_response([
        'updatedAt' => isset($stored['updatedAt']) ? $stored['updatedAt'] : null,
        'items' => $items,
        'socials' => isset($stored['socials']) && is_array($stored['socials']) ? array_values($stored['socials']) : [],
    ]);
    $response->header('Cache-Control', 'public, max-age=60');
    return $response;
}

/** A cover PNG or JPEG from hip.space, kept under its SHA-256 at most 720 px wide. */
function hip_press_bio_upload_cover(WP_REST_Request $request) {
    $body = $request->get_body();
    if (!is_string($body) || $body === '' || strlen($body) > 15 * 1024 * 1024) {
        return new WP_Error('hip_press_bio_cover_size', 'Kapak boş ya da 15 MB’tan büyük.', ['status' => 400]);
    }
    $info = @getimagesizefromstring($body);
    if (!$info || !in_array($info['mime'], ['image/png', 'image/jpeg', 'image/webp'], true)) {
        return new WP_Error('hip_press_bio_cover_type', 'Kapak PNG, JPEG ya da WebP olmalı.', ['status' => 400]);
    }
    $sha = hash('sha256', $body);
    $existing = hip_press_bio_cover($sha);
    if ($existing) {
        return rest_ensure_response($existing);
    }
    $dir = hip_press_bio_dir();
    if (!wp_mkdir_p($dir['path'])) {
        return new WP_Error('hip_press_bio_cover_dir', 'uploads/hip-press-bio klasörü açılamadı.', ['status' => 500]);
    }
    if (!function_exists('wp_tempnam')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    $temp = wp_tempnam('hip-press-bio');
    file_put_contents($temp, $body);
    $saved = false;
    $editor = wp_get_image_editor($temp);
    if (!is_wp_error($editor)) {
        $size = $editor->get_size();
        if ($size['width'] > HIP_PRESS_BIO_COVER_WIDTH) {
            $editor->resize(HIP_PRESS_BIO_COVER_WIDTH, null, false);
        }
        $editor->set_quality(84);
        $result = $editor->save($dir['path'] . '/' . $sha . '.jpg', 'image/jpeg');
        $saved = !is_wp_error($result);
    }
    if (!$saved && $info['mime'] === 'image/png') {
        // No image library on the server: the PNG is kept as it came.
        $saved = (bool) @copy($temp, $dir['path'] . '/' . $sha . '.png');
    }
    @unlink($temp);
    $cover = $saved ? hip_press_bio_cover($sha) : null;
    return $cover ? rest_ensure_response($cover) : new WP_Error('hip_press_bio_cover_save', 'Kapak kaydedilemedi.', ['status' => 500]);
}

/** The list from hip.space: checked, kept in an option, unused covers removed. */
function hip_press_bio_save(WP_REST_Request $request) {
    $data = $request->get_json_params();
    if (!is_array($data) || !isset($data['items']) || !is_array($data['items'])) {
        return new WP_Error('hip_press_bio_payload', 'items listesi gerekli.', ['status' => 400]);
    }
    $items = [];
    $problems = [];
    foreach (array_slice($data['items'], 0, HIP_PRESS_BIO_MAX_ITEMS) as $index => $raw) {
        if (!is_array($raw)) {
            continue;
        }
        $id = isset($raw['id']) && is_string($raw['id']) && preg_match('/^[a-z0-9-]{1,64}$/', $raw['id']) ? $raw['id'] : null;
        $title = isset($raw['title']) && is_string($raw['title']) ? mb_substr(sanitize_text_field($raw['title']), 0, 200) : '';
        $url = isset($raw['url']) && is_string($raw['url']) ? esc_url_raw($raw['url'], ['https', 'http']) : '';
        $shared = isset($raw['sharedAt']) && is_string($raw['sharedAt']) ? strtotime($raw['sharedAt']) : false;
        if (!$id || $title === '' || $url === '' || !$shared) {
            $problems[] = sprintf('%d. içerik eksik bilgiyle geldi.', $index + 1);
            continue;
        }
        if (!hip_press_bio_host_allowed(wp_parse_url($url, PHP_URL_HOST))) {
            $problems[] = sprintf('%s: adres bu sitenin değil.', $title);
            continue;
        }
        $cover = isset($raw['cover']) && is_string($raw['cover']) && hip_press_bio_cover($raw['cover']) ? $raw['cover'] : null;
        $items[] = ['id' => $id, 'title' => $title, 'url' => $url, 'cover' => $cover, 'sharedAt' => gmdate('c', $shared)];
    }
    $socials = [];
    foreach (isset($data['socials']) && is_array($data['socials']) ? array_slice($data['socials'], 0, 15) : [] as $raw) {
        if (!is_array($raw) || !isset($raw['platform'], $raw['url']) || !in_array($raw['platform'], HIP_PRESS_BIO_SOCIAL_PLATFORMS, true)) {
            continue;
        }
        $url = esc_url_raw((string) $raw['url'], ['https']);
        if ($url === '') {
            continue;
        }
        $socials[] = [
            'platform' => $raw['platform'],
            'label' => isset($raw['label']) && is_string($raw['label']) ? mb_substr(sanitize_text_field($raw['label']), 0, 40) : $raw['platform'],
            'handle' => isset($raw['handle']) && is_string($raw['handle']) ? mb_substr(sanitize_text_field($raw['handle']), 0, 80) : '',
            'url' => $url,
        ];
    }
    update_option(HIP_PRESS_BIO_OPTION, ['updatedAt' => gmdate('c'), 'items' => $items, 'socials' => $socials], false);
    hip_press_bio_prune(array_filter(array_column($items, 'cover')));
    return rest_ensure_response(['saved' => count($items), 'socials' => count($socials), 'problems' => $problems]);
}

/** Covers no item uses any more go after a day (a cover sent just before its list stays). */
function hip_press_bio_prune(array $keep) {
    $dir = hip_press_bio_dir();
    foreach (array_merge(glob($dir['path'] . '/*.jpg') ?: [], glob($dir['path'] . '/*.png') ?: []) as $file) {
        $sha = pathinfo($file, PATHINFO_FILENAME);
        if (!in_array($sha, $keep, true) && filemtime($file) < time() - DAY_IN_SECONDS) {
            @unlink($file);
        }
    }
}
