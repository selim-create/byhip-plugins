<?php
/**
 * Updates from plugin.byhip.studio instead of being uploaded to every site by hand.
 *
 * - The plugin header's Update URI points at plugin.byhip.studio, so WordPress (5.8+) asks this
 *   file, not wordpress.org, whether a new version exists. The answer comes from
 *   https://plugin.byhip.studio/hip-press-bridge/info.json (version, package address, SHA-256).
 * - The Plugins screen then shows WordPress's own "Update now", and this plugin's automatic
 *   updates are on: WordPress installs a new version by itself (twice-daily check).
 * - A package is installed only from https://plugin.byhip.studio and only when its SHA-256 matches
 *   the one in info.json.
 * - hip.space reads the installed version (GET hip-press/v1/bridge) and can ask the site to update
 *   now (POST hip-press/v1/bridge/update): that only starts WordPress's own automatic update run,
 *   it installs nothing it is handed.
 */

if (!defined('ABSPATH')) {
    exit;
}

const HIP_PRESS_BRIDGE_UPDATE_HOST = 'plugin.byhip.studio';
const HIP_PRESS_BRIDGE_INFO_URL = 'https://plugin.byhip.studio/hip-press-bridge/info.json';
const HIP_PRESS_BRIDGE_RELEASE_CACHE = 'hip_press_bridge_release';

function hip_press_bridge_basename() {
    return plugin_basename(HIP_PRESS_BRIDGE_FILE);
}

/** Only https://plugin.byhip.studio/… addresses are trusted for packages. */
function hip_press_bridge_trusted_url($url) {
    if (!is_string($url) || $url === '') {
        return false;
    }
    $parts = wp_parse_url($url);
    return is_array($parts)
        && isset($parts['scheme'], $parts['host'])
        && $parts['scheme'] === 'https'
        && strtolower($parts['host']) === HIP_PRESS_BRIDGE_UPDATE_HOST;
}

/**
 * The latest release from info.json, cached for six hours (one hour after a failed read).
 * Null when it cannot be read or does not look right.
 */
function hip_press_bridge_release($fresh = false) {
    if (!$fresh) {
        $cached = get_site_transient(HIP_PRESS_BRIDGE_RELEASE_CACHE);
        if (is_array($cached)) {
            return isset($cached['version']) ? $cached : null;
        }
    }
    $release = null;
    $response = wp_remote_get(HIP_PRESS_BRIDGE_INFO_URL, ['timeout' => 10, 'headers' => ['Accept' => 'application/json']]);
    if (!is_wp_error($response) && (int) wp_remote_retrieve_response_code($response) === 200) {
        $data = json_decode((string) wp_remote_retrieve_body($response), true);
        if (is_array($data)
            && isset($data['version'], $data['download_url'], $data['sha256'])
            && is_string($data['version']) && preg_match('/^\d+\.\d+\.\d+$/', $data['version'])
            && hip_press_bridge_trusted_url($data['download_url'])
            && is_string($data['sha256']) && preg_match('/^[a-f0-9]{64}$/', $data['sha256'])) {
            $release = $data;
        }
    }
    set_site_transient(HIP_PRESS_BRIDGE_RELEASE_CACHE, $release ? $release : ['failed' => true], $release ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS);
    return $release;
}

function hip_press_bridge_release_field($release, $key, $fallback = '') {
    return is_array($release) && isset($release[$key]) && is_string($release[$key]) ? $release[$key] : $fallback;
}

/** The update entry WordPress keeps for this plugin. */
function hip_press_bridge_update_item($release) {
    return [
        'id' => 'https://plugin.byhip.studio/hip-press-bridge/',
        'slug' => 'hip-press-bridge',
        'plugin' => hip_press_bridge_basename(),
        'version' => $release['version'],
        'new_version' => $release['version'],
        'url' => 'https://plugin.byhip.studio/hip-press-bridge/',
        'package' => $release['download_url'],
        'tested' => hip_press_bridge_release_field($release, 'tested'),
        'requires' => hip_press_bridge_release_field($release, 'requires', '6.0'),
        'requires_php' => hip_press_bridge_release_field($release, 'requires_php', '7.4'),
        'autoupdate' => true,
        'icons' => [],
        'banners' => [],
        'banners_rtl' => [],
        'translations' => [],
    ];
}

/** WordPress 5.8+: the answer for plugins whose Update URI is on plugin.byhip.studio. */
add_filter('update_plugins_' . HIP_PRESS_BRIDGE_UPDATE_HOST, static function ($update, $plugin_data, $plugin_file) {
    if ($plugin_file !== hip_press_bridge_basename()) {
        return $update;
    }
    $release = hip_press_bridge_release();
    return $release ? hip_press_bridge_update_item($release) : $update;
}, 10, 3);

/**
 * WordPress asks plugin.byhip.studio only after wordpress.org answers; when wordpress.org cannot
 * be reached (a firewall, a blocked host) the list of updates is not refreshed at all. So the
 * entry is also put into the list whenever it is read: the Plugins screen and the automatic
 * update run see the new version either way.
 */
add_filter('site_transient_update_plugins', static function ($transient) {
    if (!is_admin() && !wp_doing_cron() && !(defined('REST_REQUEST') && REST_REQUEST)) {
        return $transient;
    }
    $release = hip_press_bridge_release();
    if (!$release) {
        return $transient;
    }
    if (!is_object($transient)) {
        $transient = new stdClass();
    }
    if (!isset($transient->response) || !is_array($transient->response)) {
        $transient->response = [];
    }
    if (!isset($transient->no_update) || !is_array($transient->no_update)) {
        $transient->no_update = [];
    }
    $basename = hip_press_bridge_basename();
    $item = (object) hip_press_bridge_update_item($release);
    if (version_compare($release['version'], HIP_PRESS_BRIDGE_VERSION, '>')) {
        $transient->response[$basename] = $item;
        unset($transient->no_update[$basename]);
    } else {
        $item->package = '';
        $transient->no_update[$basename] = $item;
        unset($transient->response[$basename]);
    }
    return $transient;
});

/** "View details" on the Plugins screen. */
add_filter('plugins_api', static function ($result, $action, $args) {
    if ($action !== 'plugin_information' || !is_object($args) || !isset($args->slug) || $args->slug !== 'hip-press-bridge') {
        return $result;
    }
    $release = hip_press_bridge_release();
    if (!$release) {
        return $result;
    }
    return (object) [
        'name' => 'Hip Space Bridge',
        'slug' => 'hip-press-bridge',
        'version' => $release['version'],
        'author' => '<a href="https://byhip.studio">byhip.studio</a>',
        'homepage' => 'https://plugin.byhip.studio/hip-press-bridge/',
        'requires' => hip_press_bridge_release_field($release, 'requires', '6.0'),
        'requires_php' => hip_press_bridge_release_field($release, 'requires_php', '7.4'),
        'tested' => hip_press_bridge_release_field($release, 'tested'),
        'last_updated' => hip_press_bridge_release_field($release, 'released_at'),
        'download_link' => $release['download_url'],
        'sections' => [
            'description' => 'hip.space ile WordPress arasındaki köprü: taslakların SEO bilgileri ve mecra sayfaları.',
            'changelog' => wp_kses_post(hip_press_bridge_release_field($release, 'changelog_html')),
        ],
    ];
}, 10, 3);

/** This plugin updates itself automatically, whatever the per-site toggle says. */
add_filter('auto_update_plugin', static function ($update, $item) {
    if (is_object($item) && isset($item->plugin) && $item->plugin === hip_press_bridge_basename()) {
        return true;
    }
    return $update;
}, 10, 2);

/**
 * A package from plugin.byhip.studio is downloaded here and installed only when it is the one
 * info.json names and its SHA-256 matches.
 */
add_filter('upgrader_pre_download', static function ($reply, $package) {
    if ($reply !== false || !hip_press_bridge_trusted_url($package)) {
        return $reply;
    }
    $release = hip_press_bridge_release(true);
    if (!$release || $release['download_url'] !== $package) {
        return new WP_Error('hip_press_bridge_unknown_package', 'Paket, plugin.byhip.studio sürüm bilgisindeki adresle eşleşmiyor.');
    }
    if (!function_exists('download_url')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    $file = download_url($package, 300);
    if (is_wp_error($file)) {
        return $file;
    }
    if (!hash_equals($release['sha256'], (string) hash_file('sha256', $file))) {
        wp_delete_file($file);
        return new WP_Error('hip_press_bridge_checksum', 'Paketin SHA-256 özeti tutmuyor; güncelleme durduruldu.');
    }
    return $file;
}, 10, 2);

add_action('rest_api_init', static function () {
    register_rest_route('hip-press/v1', '/bridge', [
        'methods' => WP_REST_Server::READABLE,
        'callback' => 'hip_press_bridge_status',
        'permission_callback' => static function () {
            return current_user_can('edit_posts');
        },
    ]);
    register_rest_route('hip-press/v1', '/bridge/update', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'hip_press_bridge_update_now',
        'permission_callback' => static function () {
            return current_user_can('edit_others_posts');
        },
    ]);
});

function hip_press_bridge_status() {
    $release = hip_press_bridge_release();
    $latest = hip_press_bridge_release_field($release, 'version');
    return rest_ensure_response([
        'plugin' => 'hip-press-bridge',
        'version' => HIP_PRESS_BRIDGE_VERSION,
        'latest' => $latest !== '' ? $latest : null,
        'updateAvailable' => $latest !== '' && version_compare($latest, HIP_PRESS_BRIDGE_VERSION, '>'),
        'autoUpdate' => true,
        'cronDisabled' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON,
        'updaterDisabled' => (defined('AUTOMATIC_UPDATER_DISABLED') && AUTOMATIC_UPDATER_DISABLED) || (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS),
        'wordpress' => get_bloginfo('version'),
        'php' => PHP_VERSION,
    ]);
}

/**
 * "Update now" from hip.space: reads info.json again, refreshes WordPress's list of plugin
 * updates and starts its automatic update run at once (WP-Cron). WordPress installs the
 * package itself, the same way as its twice-daily run; nothing is installed from this request.
 */
function hip_press_bridge_update_now() {
    $release = hip_press_bridge_release(true);
    if (!$release) {
        return new WP_Error('hip_press_bridge_no_release', 'plugin.byhip.studio sürüm bilgisi okunamadı.', ['status' => 502]);
    }
    if (!version_compare($release['version'], HIP_PRESS_BRIDGE_VERSION, '>')) {
        return rest_ensure_response(['started' => false, 'version' => HIP_PRESS_BRIDGE_VERSION, 'latest' => $release['version'], 'message' => 'Eklenti güncel.']);
    }
    if ((defined('AUTOMATIC_UPDATER_DISABLED') && AUTOMATIC_UPDATER_DISABLED) || (defined('DISALLOW_FILE_MODS') && DISALLOW_FILE_MODS)) {
        return new WP_Error('hip_press_bridge_updates_off', 'Bu sitede otomatik güncellemeler kapalı (wp-config.php); eklenti Eklentiler sayfasından güncellenmeli.', ['status' => 409]);
    }
    if (function_exists('wp_clean_plugins_cache')) {
        wp_clean_plugins_cache(true);
    } else {
        delete_site_transient('update_plugins');
    }
    wp_update_plugins();
    // WordPress's own twice-daily event may be hours away: one more run now (a repeat within ten minutes is ignored).
    wp_schedule_single_event(time(), 'wp_maybe_auto_update');
    spawn_cron();
    return rest_ensure_response(['started' => true, 'version' => HIP_PRESS_BRIDGE_VERSION, 'latest' => $release['version'], 'message' => 'Güncelleme başlatıldı; birkaç dakika içinde yeni sürüm yüklenir.']);
}
