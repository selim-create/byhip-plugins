# Hip Space Bridge

## 0.2.0
- Kendini güncelliyor: yeni sürümler plugin.byhip.studio'dan gelir; Eklentiler sayfasında WordPress'in "Şimdi güncelle" düğmesi çıkar ve otomatik güncelleme açıktır.
- Paket yalnız plugin.byhip.studio'dan ve SHA-256 özeti tutarsa kurulur.
- hip.space için sürüm bilgisi (`hip-press/v1/bridge`) ve "şimdi güncelle" (`hip-press/v1/bridge/update`) uç noktaları.

## 0.1.0
- Taslakların SEO bilgileri (Rank Math başlık, açıklama, odak anahtar kelime) ve kısa adres.
